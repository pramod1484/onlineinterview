<footer class="container">
    <p class="credit small">&copy; 2014 <a href="<?php echo BASEPATH;?>">EECRM</a></p>
</footer>    
<script type="text/javascript">
    var BASEPATH = "<?php echo BASEPATH;?>";
</script>
<script type="text/javascript" src="<?php echo BASEPATH; ?>js/common.js"></script>        
</body>
</html>
