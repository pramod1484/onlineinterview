<?php

/**
 * Defining all necessary configuration
 * 
 */
define("DBHOST","localhost");
define("DBPORT","");
define("DBUSER","da_admin");
define("DBPASS","ZUvylywf");
define("DBNAME","eastern_crm");