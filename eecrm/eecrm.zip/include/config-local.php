<?php

/**
 * Defining all necessary configuration
 * 
 */
define("DBHOST","localhost");
define("DBPORT","");
define("DBUSER","root");
define("DBPASS","root");
define("DBNAME","crm_ee");