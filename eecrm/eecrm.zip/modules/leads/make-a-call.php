<?php
session_start();
require_once dirname(__DIR__).'/../include-locations.php';
require_once dirname(__DIR__)."/../include/define.php";
require_once dirname(__DIR__)."/../include/database.php";
require_once dirname(__DIR__)."/../include/utils-helpers.php";
require_once dirname(__DIR__)."/../include/utils-calls.php";

if (!empty($_POST)) {
    if (!empty($_POST['leadId'])) {
        $data = array();
        $data['user_id'] = getSessionValue('user');
        $data['lead_id'] = $_POST['leadId'];
        $data['created_at'] = getFormattedDate(NULL, "Y-m-d");
        $data['start_time'] = getFormattedDate();
        
        addNewCall($data);
    }
}